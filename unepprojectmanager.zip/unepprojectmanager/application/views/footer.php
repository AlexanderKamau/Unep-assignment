<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-primary fixed-bottom text-center">
	
</nav>

</body>
</html>